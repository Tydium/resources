# Ideas

## Marshmellows \
## Cereal
## Cake Variants
## Ramen
## Doughnuts
## Mac and Cheese
## Pancakes
## Mashed Potatoes 
## Sushi
## Smores 
## Different cookies
## MORE SOUPPPP
## Blueberries 
## More pies
## Sweet berry pie